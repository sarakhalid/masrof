# -*- coding: utf-8 -*-


from . import e_wallet
from . import res_partner
from . import transactions
from . import pos_order
from . import school
from . import wallet_operations
from . import education_administration
from . import contract
from . import product

